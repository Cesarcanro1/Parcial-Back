# Parcial-Back

API REST construida con Spring Boot para la gestión de clínicas. Incluye CRUD básico para la entidad **Clínica** cumpliendo los lineamientos del parcial (controladores, servicios, repositorios, entidades, DTOs, uso de Lombok y ModelMapper, y persistencia con H2).

## Stack

- Java 17 + Spring Boot 3
- Spring Data JPA + H2 en memoria
- Lombok y ModelMapper para reducir código repetitivo y manejo de DTOs

## Ejecución local

```powershell
mvn spring-boot:run
```

La aplicación quedará escuchando en `http://localhost:8080` y la consola de H2 estará disponible en `http://localhost:8080/h2-console` (usuario `sa`, sin contraseña).

## Endpoints principales

| Método | Ruta              | Descripción                       |
|--------|-------------------|-----------------------------------|
| GET    | `/api/clinicas`   | Devuelve la lista de clínicas.    |
| POST   | `/api/clinicas`   | Crea una nueva clínica.           |

El cuerpo del `POST` debe cumplir:

```json
{
  "nombre": "Clínica Central",
  "direccion": "Calle 123",
  "cantidadCamas": 42,
  "telefono": "5551234",
  "ciudad": "Bogotá"
}
```

La respuesta incluye el identificador y la fecha de creación generados por el backend.


```powershell
mvn test
```
