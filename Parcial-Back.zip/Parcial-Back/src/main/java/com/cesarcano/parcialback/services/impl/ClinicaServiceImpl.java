package com.cesarcano.parcialback.services.impl;

import com.cesarcano.parcialback.dto.ClinicaRequestDto;
import com.cesarcano.parcialback.dto.ClinicaResponseDto;
import com.cesarcano.parcialback.entities.Clinica;
import com.cesarcano.parcialback.repositories.ClinicaRepository;
import com.cesarcano.parcialback.services.ClinicaService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ClinicaServiceImpl implements ClinicaService {

    private final ClinicaRepository clinicaRepository;
    private final ModelMapper modelMapper;

    @Override
    public List<ClinicaResponseDto> listarClinicas() {
        return clinicaRepository.findAll()
                .stream()
                .map(clinica -> modelMapper.map(clinica, ClinicaResponseDto.class))
                .toList();
    }

    @Override
    public ClinicaResponseDto crearClinica(ClinicaRequestDto request) {
        Clinica clinica = modelMapper.map(request, Clinica.class);
        Clinica guardada = clinicaRepository.save(clinica);
        return modelMapper.map(guardada, ClinicaResponseDto.class);
    }
}
