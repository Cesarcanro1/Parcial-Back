package com.cesarcano.parcialback.controllers;

import com.cesarcano.parcialback.dto.ClinicaRequestDto;
import com.cesarcano.parcialback.dto.ClinicaResponseDto;
import com.cesarcano.parcialback.services.ClinicaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/clinicas")
@RequiredArgsConstructor
public class ClinicaController {

    private final ClinicaService clinicaService;

    @GetMapping
    public List<ClinicaResponseDto> listarClinicas() {
        return clinicaService.listarClinicas();
    }

    @PostMapping
    public ResponseEntity<ClinicaResponseDto> crearClinica(@Valid @RequestBody ClinicaRequestDto requestDto) {
        ClinicaResponseDto creada = clinicaService.crearClinica(requestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(creada);
    }
}
