package com.cesarcano.parcialback.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClinicaRequestDto {

    @NotBlank
    private String nombre;

    @NotBlank
    private String direccion;

    @NotNull
    @Min(1)
    private Integer cantidadCamas;

    @NotBlank
    @Pattern(regexp = "^[0-9+\\-() ]{7,20}$", message = "El teléfono debe contener entre 7 y 20 caracteres numéricos")
    private String telefono;

    @NotBlank
    private String ciudad;
}
