package com.cesarcano.parcialback.services;

import com.cesarcano.parcialback.dto.ClinicaRequestDto;
import com.cesarcano.parcialback.dto.ClinicaResponseDto;

import java.util.List;

public interface ClinicaService {

    List<ClinicaResponseDto> listarClinicas();

    ClinicaResponseDto crearClinica(ClinicaRequestDto request);
}
